import { makeStyles } from "@mui/styles";

export const DaysCss = makeStyles({

    Linkstyle:{
        textDecoration: "none",
        width: 115,
        height: 40, margin: 19,
        alignItems: "center",
        display: "flex",
        justifyItems: "center",
        justifyContent: "center",
        cursor: "pointer",
        marginTop:"10%"
    }
})